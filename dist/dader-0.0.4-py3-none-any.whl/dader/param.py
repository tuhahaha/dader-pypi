model_root='checkpoint'
encoder_path = "encoder.pt"
matcher_path = "matcher.pt"
alignment_path = "alignment.pt"

default_bert = 'bert-base-multilingual-cased'
default_bart = 'facebook/bart-large'

intermediate_size = 3072
